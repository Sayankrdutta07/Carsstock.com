function startShopping() {
    document.getElementById('welcome-popup').style.display = 'none';
    document.getElementById('home-page').style.display = 'block';
}

// Filter Cars
function filterCars() {
    const priceFilter = document.getElementById('price-filter').value;
    const fuelTypeFilter = document.getElementById('fuel-type-filter').value;
    const searchInput = document.getElementById('search-input').value.toLowerCase();

    document.querySelectorAll('.car-item').forEach(car => {
        const price = parseInt(car.getAttribute('data-price'));
        const fuelType = car.getAttribute('data-fuel');
        const carName = car.querySelector('h3').innerText.toLowerCase();

        const matchesSearch = carName.includes(searchInput);
        const matchesPrice = !priceFilter || price <= parseInt(priceFilter);
        const matchesFuel = !fuelTypeFilter || fuelType === fuelTypeFilter;

        car.style.display = matchesSearch && matchesPrice && matchesFuel ? 'block' : 'none';
    });
}

// Geolocation
function getLocation() {
    if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(showPosition, showError);
    } else {
        alert("Geolocation is not supported.");
    }
}

function showPosition(position) {
    console.log(`Latitude: ${position.coords.latitude}`);
    console.log(`Longitude: ${position.coords.longitude}`);
}

function showError(error) {
    console.log(`Error: ${error.message}`);
}

window.onload = getLocation;

function openWhatsApp() {
    const phone = '916291997880';
    const message = encodeURIComponent('Hello! Interested in cars.');
    window.open(`https://wa.me/${phone}?text=${message}`, '_blank');
}
